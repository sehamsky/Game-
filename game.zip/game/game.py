import random
import time
import threading
import pygame
from pygame import mixer
import sys
import msvcrt
from select import select

# Global event to detect if user is typing
is_user_typing = threading.Event()

def initialize_audio():
    try:
        pygame.init()
        mixer.init()
        mixer.music.set_volume(0.3)
        return True
    except:
        return False

def play_sound(filename, loops=0, volume=1.0):
    try:
        sound = mixer.Sound(filename)
        sound.set_volume(volume)
        sound.play(loops=loops)
        return sound
    except Exception as e:
        print(f"(Couldn't play {filename} - {e})")
        return None

def dramatic_intro():
    print("\n[INTELLIGENCE OFFICER]: Agent, we have a critical mission for you.")
    time.sleep(2)
    print("A dangerous cyber criminal has encrypted vital intelligence.")
    time.sleep(2)
    print("We've tracked their location, but local police are also en route.")
    time.sleep(2)
    print("You must decrypt the message before the police arrive at their location.")
    time.sleep(2)
    print("If they catch you hacking their systems, you'll be arrested.")
    time.sleep(2)
    print("\nInitializing hacking terminal...")
    time.sleep(1.5)
    print("Bypassing firewall...")
    time.sleep(2)
    print("Accessing secure network...")
    time.sleep(1)
    print("Connection established!\n")
    time.sleep(1)

def generate_challenge():
    messages = [
        "THE SECRET MEETING IS AT MIDNIGHT",
        "TRANSFER THE FUNDS TO ACCOUNT 4839",
        "THE LAUNCH CODES ARE TANGO ALPHA",
        "THE PACKAGE IS AT THE DROP POINT",
        "USE CREDENTIALS ADMIN BLACKHAT123"
    ]
    original_message = random.choice(messages)
    shift = random.randint(1, 5)
    encrypted = []
    for char in original_message:
        if char.isalpha():
            shifted = ord(char) + shift
            if shifted > ord('Z'):
                shifted -= 26
            encrypted.append(chr(shifted))
        else:
            encrypted.append(char)
    return {
        'shift': shift,
        'ciphertext': ''.join(encrypted),
        'original_message': original_message
    }

def display_hacker_art():
    print(r"""
     _   _            _    _            _____          _      
    | | | |          | |  (_)          |  __ \        | |     
    | |_| | __ _  ___| | ___  __ _  ___| |  | | __ ___| | ___ 
    |  _  |/ _` |/ __| |/ / |/ _` |/ _ \ |  | |/ _` \ \ / / |
    | | | | (_| | (__|   <| | (_| |  __/ |__| | (_| |\ V /|_|
    \_| |_/\__,_|\___|_|\_\_|\__, |\___|_____/ \__,_| \_/ (_)
                              __/ |                          
                             |___/                           
    """)

def play_arrest_sound():
    play_sound('siren.mp3', volume=0.8)
    time.sleep(1)
    play_sound('arrest.mp3', volume=1.0)

def input_with_timeout(prompt, timeout):
    if prompt:
        print(prompt, end='', flush=True)
    start_time = time.time()
    if sys.platform == 'win32':
        result = []
        while True:
            if msvcrt.kbhit():
                char = msvcrt.getwch()
                if char == '\r':
                    print()
                    return ''.join(result)
                elif char == '\x08':
                    if result:
                        result.pop()
                        sys.stdout.write('\b \b')
                        sys.stdout.flush()
                else:
                    result.append(char)
                    sys.stdout.write(char)
                    sys.stdout.flush()
            if time.time() - start_time > timeout:
                return None
            time.sleep(0.05)
    else:
        rlist, _, _ = select([sys.stdin], [], [], timeout)
        if rlist:
            return sys.stdin.readline().strip()
        return None

def countdown_thread(start_time, time_limit, audio_available, stop_event):
    checkpoints = [15, 30, 45]
    warnings_triggered = set()

    while not stop_event.is_set():
        elapsed = time.time() - start_time

        if int(elapsed) in checkpoints and int(elapsed) not in warnings_triggered:
            warnings_triggered.add(int(elapsed))
            if not is_user_typing.is_set():
                print(f"\n⏳ {int(elapsed)} seconds have passed!")
                if int(elapsed) == 15:
                    print("💡 HURRY! The police have your coordinates.")
                elif int(elapsed) == 30:
                    print("🚨 SIRENS heard nearby!")
                elif int(elapsed) == 45:
                    print("🚪 They're at the door!")
            if audio_available:
                if int(elapsed) == 30:
                    play_sound('siren.mp3', volume=0.7)
                elif int(elapsed) == 45:
                    play_sound('break.mp3', volume=0.8)

        if elapsed > time_limit * 0.9 and not is_user_typing.is_set():
            print("\n⚠️ FINAL WARNING: They're breaking in!")

        time.sleep(1)

def main():
    audio_available = initialize_audio()
    dramatic_intro()

    if audio_available:
        mixer.music.load('theme.mp3')
        mixer.music.play(loops=-1)

    display_hacker_art()
    print("Welcome to Hacker Decryption Challenge!")
    print("Decrypt the secret message by shifting letters back.")
    print("You have 60 seconds before the police catch you!\n")

    challenge = generate_challenge()
    print("Encrypted message intercepted:")
    print(f"Ciphertext: {challenge['ciphertext']}\n")

    TIME_LIMIT = 60
    start_time = time.time()
    stop_event = threading.Event()
    timer_thread = threading.Thread(target=countdown_thread, args=(start_time, TIME_LIMIT, audio_available, stop_event))
    timer_thread.daemon = True
    timer_thread.start()

    printed_prompt = False

    while True:
        elapsed = time.time() - start_time
        if elapsed >= TIME_LIMIT:
            print("\n\n⏰ TIME'S UP!")
            if audio_available:
                play_arrest_sound()
            print("The police have arrested you. Game over!")
            print(f"The original message was: {challenge['original_message']}")
            print(f"The shift was: {challenge['shift']}")
            break

        if not printed_prompt:
            print("\nOptions:\n1. Try to decrypt\n2. Guess the shift amount\n3. Quit\nChoose (1-3): ", end='', flush=True)
            printed_prompt = True

        user_input = input_with_timeout("", 1)

        if user_input is None:
            continue

        user_input = user_input.strip()
        printed_prompt = False

        if user_input == '3':
            print("You abandoned the mission. The target got away.")
            break
        elif user_input == '1':
            try:
                is_user_typing.set()
                attempt = input("Enter your decryption attempt: ").upper()
            finally:
                is_user_typing.clear()

            if attempt == challenge['original_message']:
                print("\n✅ SUCCESS! You decrypted the message!")
                print(f"Correct message: {challenge['original_message']}")
                print("You escaped before the police arrived! You win!")
                break
            else:
                print("\n❌ Incorrect decryption! Try again.")
        elif user_input == '2':
            try:
                is_user_typing.set()
                guess = int(input("Guess the shift amount (1-5): "))
            except ValueError:
                print("Please enter a number between 1-5")
            else:
                if guess == challenge['shift']:
                    print(f"\n🔑 Correct! The shift was {challenge['shift']}")
                    print(f"The message is: {challenge['original_message']}")
                    print("You can now decrypt it properly!")
                else:
                    print("\nWrong shift amount! Try again.")
            finally:
                is_user_typing.clear()
        else:
            print("Invalid choice. Try again.")

    stop_event.set()
    timer_thread.join()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nMission aborted. The police are on your trail!")
    finally:
        pygame.quit()
